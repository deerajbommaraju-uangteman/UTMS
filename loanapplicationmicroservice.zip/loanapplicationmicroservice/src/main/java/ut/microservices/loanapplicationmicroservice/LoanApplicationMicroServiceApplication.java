package ut.microservices.loanapplicationmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanApplicationMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanApplicationMicroServiceApplication.class, args);
	}

}
