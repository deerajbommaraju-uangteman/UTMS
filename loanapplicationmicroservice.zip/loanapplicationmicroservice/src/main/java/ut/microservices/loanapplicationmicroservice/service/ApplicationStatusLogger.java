package ut.microservices.loanapplicationmicroservice.service;

/**
 * ApplicationStatusLogger
 */
public class ApplicationStatusLogger {

    
}