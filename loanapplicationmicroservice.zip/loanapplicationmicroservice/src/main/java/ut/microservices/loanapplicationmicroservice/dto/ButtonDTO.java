package ut.microservices.loanapplicationmicroservice.dto;
/**
 * ButtonDTO
 */
public class ButtonDTO {

    public String title;
    public String key;
    public String action;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}